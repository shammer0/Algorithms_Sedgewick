
public class Percolation {
	private final int MIN;
	private final int MAX;
	private int count = 0;
	private int topSite;
	private int bottomSite;
	private int[][] grid;
	private int[] size;
	private int[] parent;
	private int[] status; // 0 : BLOCKED, 1 : OPEN
	
	public Percolation(int n) {
		if (n <= 0)
			throw new IllegalArgumentException("Error");
		MIN = 1;		
		MAX = n;
		grid = new int[n][n];
		size = new int[n*n + 2];
		// Blocked is -1, Open is !-1, 
		// and Full is find(topSite) == find(node)
		parent = new int[n*n + 2];
		status = new int[n*n + 2];
		
		// Virtual Sites
		topSite = n*n;
		bottomSite = n*n + 1;
		
		int name = 0;
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				grid[i][j] = name;
				size[name] = 1;
				parent[name] = name;
				status[name] = 0;
				name++;
			}
		}
		size[topSite] = 1;
		parent[topSite] = topSite;
		status[topSite] = 1;
		size[bottomSite] = 1;
		parent[bottomSite] = bottomSite;
		status[bottomSite] = 1;
	}
	
	public void open(int row, int col) {
		validate(row);
		validate(col);
		if(isOpen(row,col)){
			return;
		}

		int targetSite = grid[row-1][col-1];
		// int top = grid[row-2][col-1];
		// int right = grid[row-1][col];
		// int bottom = grid[row][col-1];
		// int left = grid[row-1][col-2];
		
		status[targetSite] = 1;
		//top
		if(row-1 == 0){
			union(targetSite, topSite);
		} else {
			if(isOpen(row-1,col))
				union(targetSite, grid[row-2][col-1]);
		}
		//right
		if(col-1 != MAX-1 && isOpen(row,col+1))
			union(targetSite, grid[row-1][col]);
		//left
		if(col-1 != 0 && isOpen(row,col-1))
			union(targetSite, grid[row-1][col-2]);
		//bottom
		if(row-1 == MAX-1 && find(targetSite) == find(topSite)) {
			union(targetSite, bottomSite);
		} else {
			if(isOpen(row+1,col))
				union(targetSite, grid[row][col-1]);
		}
		
		
		count++;
		
	}
	
	public boolean isOpen(int row, int col) {
		validate(row);
		validate(col);
		return status[grid[row-1][col-1]] == 1;
	}
	
	public boolean isFull(int row, int col) {
		validate(row);
		validate(col);
		
		return find(grid[row-1][col-1]) == find(topSite);
	}
	
	public int numberOfOpenSites() {
		return count;
	}
	
	public boolean percolates() {
		return find(bottomSite) == find(topSite); 
	}
	
	
	private void union(int p, int q) {
		int i = find(p);
		int j = find(q);
		if (i == j) return;
		
		if(size[i] > size[j]) {
			parent[j] = i;
			size[i] += size[j];
		} else {
			parent[i] = parent[j];
			size[j] += size[i];
		}
	}
	
	private int find(int p) {
		while(p != parent[p]) {
			p = parent[p];
		}
		return p;
	}
	
	private void validate(int i) {
		if(i < MIN || i > MAX)
			throw new IllegalArgumentException("Error bad input: " + i);
	}
}