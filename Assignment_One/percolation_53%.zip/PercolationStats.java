
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
	private int trials;
	private int size;
	private double[] thresholds;
	
	public PercolationStats(int n, int trials) {
		if(n <= 0 || trials <= 0) {
			throw new IllegalArgumentException("Error");
		}
		this.trials = trials;
		this.size = n;
		this.thresholds = new double[trials];
	}
	
	// sample mean of percolation threshold
    public double mean() {
		return StdStats.mean(thresholds);
	}

    // sample standard deviation of percolation threshold
    public double stddev() {
		return StdStats.stddev(thresholds);
	}

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
		return mean() - stddev();
	}

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
		return mean() + stddev();
	}

	// test client (see below)
	public static void main(String[] args) {
		PercolationStats percStats = 
		new PercolationStats(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
		
		Percolation percolation = new Percolation(percStats.size);
		for(int i = 0; i < percStats.trials; i++) {
			while(!percolation.percolates()) {
				int row = StdRandom.uniformInt(1,percStats.size+1);
				int col = StdRandom.uniformInt(1,percStats.size+1);
				percolation.open(row,col);
				//System.out.println("While in main");
			}
			percStats.thresholds[i] = (double) percolation.numberOfOpenSites() / (percStats.size * percStats.size);
		}
			
		StdOut.println("mean = " + percStats.mean());
		StdOut.println("stddev = " + percStats.stddev());
		StdOut.println("95% = " + percStats.confidenceLo() + ", " + percStats.confidenceHi());
	}
}